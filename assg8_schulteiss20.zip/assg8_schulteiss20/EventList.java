/*
 * @author Sariah Schulteis 
 * A class that can insert, delete, and sort the queue
 */
package assg8_schulteiss20;

public class EventList {
	private Event beginning;
	private int size;

	/*
	 * A constructor for EventList class
	 */
	public EventList() {
		beginning = null;
		size = 0;
	}

	/*
	 * returns size if size is 0
	 * 
	 * @return size == 0
	 */
	public boolean isEmpty() {
		return size == 0;
	}

	/*
	 * inserts into the queue
	 * 
	 * @param Event newEvent
	 * 
	 * @return false if newEvent is null
	 * 
	 * @return true if beginning is null
	 */
	public boolean insertQueue(Event newEvent) {
		if (newEvent == null)
			return false;

		if (beginning == null) {
			beginning = new Event(newEvent, beginning);
			size++;
			return true;
		}

		Event spot = beginning;

		while (spot.getNext() != null) {
			spot = spot.getNext();
		}

		spot.setNext(new Event(newEvent));

		size++;
		return true;
	}

	/*
	 * Sorts the queue
	 * 
	 * @param Event newEvent
	 * 
	 * @return false if null
	 * 
	 * @return true if beginning is null or is newEvent arriveTime is less than
	 * beginning arriveTime
	 */
	public boolean SortQueue(Event newEvent) {
		if (newEvent == null)
			return false;

		if (beginning == null || newEvent.getArriveTime() < beginning.getData().getArriveTime()) {
			beginning = new Event(newEvent, beginning);
			size++;
			return true;
		}

		Event spot = beginning;
		Event prior = null;

		while (spot != null && (newEvent.getArriveTime() > spot.getData().getArriveTime())) {
			prior = spot;
			spot = spot.getNext();
		}

		if (spot != null && (newEvent.getEventType() == 'D' && spot.getData().getEventType() == 'A')) {
			if (newEvent.getArriveTime() == spot.getData().getArriveTime()) {
				prior = spot;
				spot = spot.getNext();
			}
		}

		Event newNode = new Event(newEvent, prior.getNext());
		prior.setNext(newNode);
		size++;
		return true;
	}

	/*
	 * removes from the queue
	 * 
	 * @return false if size == 0, else true
	 */
	public boolean deleteQueue() {
		if (size == 0)
			return false;

		beginning = beginning.getNext();
		size--;

		return true;
	}

	/*
	 * peeks at front
	 * 
	 * @return new Event if size == 0 if not, @return beginning.getData
	 */
	public Event peekBeginning() {
		if (size == 0) {
			System.out.println("List is empty!");
			return new Event();
		} else
			return beginning.getData();
	}

	/*
	 * gets the size
	 * 
	 * @return size
	 */
	public int getSize() {
		return size;
	}
}