/*
 * @Author Sariah Schulteis 
 * A class that has constructors, get methods, set methods, toString, and compareTo
 */
package assg8_schulteiss20;

public class Event {
	private int arriveTime;
	private int transactionTime;
	private char eventType;

	/*
	 * A constructor for Event class
	 */
	public Event() {
		arriveTime = 0;
		transactionTime = 0;
		eventType = ' ';
	}

	/*
	 * A constructor for Event class
	 * 
	 * @param aTime and tTime
	 */
	public Event(int aTime, int tTime) {
		arriveTime = aTime;
		transactionTime = tTime;
		eventType = 'A';
	}

	/*
	 * A constructor for Event class
	 * 
	 * @param aTime, tTime, and type
	 */
	public Event(int aTime, int tTime, char type) {
		arriveTime = aTime;
		transactionTime = tTime;
		eventType = type;
	}

	Event data;
	Event next;

	/*
	 * A constructor for Event class
	 * 
	 * @param Event newData
	 */
	public Event(Event newData) {
		data = newData;
		next = null;
	}

	/*
	 * A constructor for Event class
	 * 
	 * @param Event newData, Event newNext
	 */
	public Event(Event newData, Event newNext) {
		data = newData;
		next = newNext;
	}

	/*
	 * Gets data
	 * 
	 * @return data
	 */
	public Event getData() {
		return data;
	}

	/*
	 * Gets next
	 * 
	 * @return next
	 */
	public Event getNext() {
		return next;
	}

	public void setNext(Event newNext) {
		next = newNext;
	}

	/*
	 * Gets ArriveTime
	 * 
	 * @return arriveTime
	 */
	public int getArriveTime() {
		return arriveTime;
	}

	/*
	 * Gets TransactionTime
	 * 
	 * @return transactionTime
	 */
	public int getTransactionTime() {
		return transactionTime;
	}

	/*
	 * Gets EventType
	 * 
	 * @return eventType
	 */
	public char getEventType() {
		return eventType;
	}

	/*
	 * Compares arriveTime
	 * 
	 * @return this.arriveeTime - b.arriveTime
	 */
	public int compareTo(Event b) {
		return this.arriveTime - b.arriveTime;
		// if it returns negative,the calling event is before event b
		// if it returns positive,the calling event is after event b
	}

	/*
	 * toString
	 * 
	 * @return this.eventType, this.arriveTime, transactionTime
	 */
	public String toString() {
		return this.eventType + "," + this.arriveTime + "," + (transactionTime >= 0 ? transactionTime : "");
	}
}