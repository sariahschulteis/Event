/*
 * @author Sariah Schulteis
 * A class that processes arrival time and departure time
 */
package assg8_schulteiss20;

import java.io.*;

import java.util.*;

public class Simulation {
	/*
	 * reads file and processes arrival time and departure time
	 */
	public static void main(String[] args) throws FileNotFoundException {

		int counter = 0;
		int totalArrive = 0;
		int totalDeparture = 0;
		int totalProcess = 0;
		double averageWait = 0;

		String filename = "assg8_input.txt";
		Scanner dataFile = new Scanner(new File(filename));

		EventList bankQueue = new EventList();
		EventList eventList = new EventList();

		boolean tellerAvailable = true;

		int a, t;

		while (dataFile.hasNext()) {
			a = dataFile.nextInt();
			t = dataFile.nextInt();

			Event newArriveEvent = new Event(a, t);
			eventList.SortQueue(newArriveEvent);
		}
		dataFile.close();

		System.out.println("Simulation Begins");

		while (!eventList.isEmpty()) {
			Event newEvent = eventList.peekBeginning();

			int time = newEvent.getArriveTime();
			if (newEvent.getEventType() == 'A') {
				eventList.deleteQueue();
				Event customer = newEvent;
				if (bankQueue.isEmpty() && tellerAvailable) {
					int departureTime = time + newEvent.getTransactionTime();
					Event newDepartureEvent = new Event(departureTime, 0, 'D');
					eventList.SortQueue(newDepartureEvent);
					tellerAvailable = false;
				} else {
					bankQueue.insertQueue(customer);
				}

				System.out.println("Processing an arrival event at time:\t" + customer.getArriveTime());
				counter++;
				totalArrive += customer.getArriveTime();
				totalProcess += customer.getTransactionTime();
			} else {
				eventList.deleteQueue();

				if (!bankQueue.isEmpty()) {
					Event customer = bankQueue.peekBeginning();
					bankQueue.deleteQueue();
					int departureTime = time + customer.getTransactionTime();
					Event newDepartureEvent = new Event(departureTime, 0, 'D');
					eventList.SortQueue(newDepartureEvent);
				} else {
					tellerAvailable = true;
				}

				System.out.println("Processing a departure event at time:\t" + time);
				totalDeparture += time;
			}
		}

		if (counter > 0) {
			averageWait = (double) (totalDeparture - totalProcess - totalArrive) / counter;
		}

		System.out.println("Simulation Ends");
		System.out.println("\nFinal Statistics:\n");
		System.out.println("\tTotal number of people processed: " + counter);
		System.out.println("\tAverage amount of time spent waiting: " + averageWait);

	}

	/*
	 * prints out arrival time
	 */
	public static void arrival(Event customer) {
		System.out.println("Processing an arrival event at time:\t" + customer.getArriveTime());
	}

	/*
	 * prints out departure time
	 */
	public static void departure(Event currentTime) {
		System.out.println("Processing a departure event at time:\t" + currentTime);
	}
}